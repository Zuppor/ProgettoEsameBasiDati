create function func_insert_player_attribute(attr player_attribute) returns character
    language plpgsql
as
$$
begin
    insert into player_attribute values (attr.player_id,attr.date,attr.name,attr.val);

    if FOUND then
        return '0';
    else
        return '1';
    end if;

    exception
    when not_null_violation then
        raise info 'Errore: vincolo not null violato';
        return '3';
    when foreign_key_violation then
        raise info 'Errore: chiave etserna non presente';
        return '4';
    when unique_violation then
        raise info 'Errore: vincolo unique violato';
        return '5';
end;
$$;

alter function func_insert_player_attribute(player_attribute) owner to postgres;

