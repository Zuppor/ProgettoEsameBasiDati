create function func_insert_bet(b bets) returns character
    language plpgsql
as
$$
begin

        if (select func_check_bet(b) = 0)  then
            insert into bets (match_id, partner_id, bet, currency_id, value) values (b.match_id,b.partner_id,b.bet,b.currency_id,b.value);

            if FOUND then
                return '0';
            else
                return '1';
            end if;
        else
            raise info 'Errore: scommessa già presente da parte di questa società o società inesistente';
            return '5';
        end if;


        exception
            when not_null_violation then
                raise info 'Errore: vincolo di not null violato';
                return '2';
            when unique_violation then
                raise info 'Errore: stai inserendo dati relativi ad una scommessa già presente';
                return '3';
            when foreign_key_violation then
                raise info 'Errore: vincolo chiave esterna violato';
                return '4';
    end;
$$;

alter function func_insert_bet(bets) owner to postgres;

