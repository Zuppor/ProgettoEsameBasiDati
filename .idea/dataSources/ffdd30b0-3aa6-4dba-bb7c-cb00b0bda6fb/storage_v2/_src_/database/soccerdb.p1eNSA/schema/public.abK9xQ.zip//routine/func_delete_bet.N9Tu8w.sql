create function func_delete_bet(m_id integer, p_id integer, b character, curr character) returns character
    language plpgsql
as
$$
begin

    delete from bets where match_id = m_id and partner_id = p_id and bet = b and currency_id = curr;

    if FOUND then
        return '0';
    else
        return '1';
    end if;

exception
    when not_null_violation then
        raise info 'Errore: vincolo di not null violato';
        return '2';
    when unique_violation then
        raise info 'Errore: stai inserendo dati relativi ad un team già presente';
        return '3';
    when foreign_key_violation then
        raise info 'Errore: vincolo chiave esterna violato';
        return '4';
end;
$$;

alter function func_delete_bet(integer, integer, char, char) owner to postgres;

