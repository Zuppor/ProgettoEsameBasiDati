create function func_delete_match(m_id integer, op_id integer, lev smallint) returns character
    language plpgsql
as
$$
begin
        if(lev == 0) then
            delete from public.match where id = m_id;
        else
            delete from public.match where id = m_id and operator_id = op_id;
        end if;


        if FOUND then
            return '0';
        else
            return '1';
        end if;
    end;
$$;

alter function func_delete_match(integer, integer, smallint) owner to postgres;

