create function func_insert_country(country_name character varying) returns integer
    language plpgsql
as
$$
declare
        ret_id country.id%TYPE;
    begin
        insert into country(name) values (country_name) returning id into ret_id;

        if FOUND then
            return ret_id;
        else
            return -1;
        end if;

    exception
        when not_null_violation then
            raise info 'Errore: vincolo di not null violato';
            return -2;
        when unique_violation then
            raise info 'Errore: stai inserendo dati relativi ad un paese già presente';
            return -3;
    end;
$$;

alter function func_insert_country(varchar) owner to postgres;

