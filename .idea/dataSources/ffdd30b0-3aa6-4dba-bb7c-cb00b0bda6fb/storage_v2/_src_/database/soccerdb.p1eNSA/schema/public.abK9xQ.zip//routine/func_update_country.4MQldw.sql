create function func_update_country(c country) returns character
    language plpgsql
as
$$
begin
    update country
    set name = c.name
    where id = c.id;

    if FOUND then
        return '0';
    else
        return '1';
    end if;

exception
    when unique_violation then
        raise info 'League già presente';
        return '2';
end;
$$;

alter function func_update_country(country) owner to postgres;

