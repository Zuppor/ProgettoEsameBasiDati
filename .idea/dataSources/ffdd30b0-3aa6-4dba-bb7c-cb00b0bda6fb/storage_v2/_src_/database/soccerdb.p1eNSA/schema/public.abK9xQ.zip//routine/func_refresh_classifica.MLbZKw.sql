create function func_refresh_classifica() returns trigger
  security definer
  language plpgsql
as
$$
begin
    refresh materialized view classifica;

    return new;
  end;
$$;

alter function func_refresh_classifica() owner to postgres;

