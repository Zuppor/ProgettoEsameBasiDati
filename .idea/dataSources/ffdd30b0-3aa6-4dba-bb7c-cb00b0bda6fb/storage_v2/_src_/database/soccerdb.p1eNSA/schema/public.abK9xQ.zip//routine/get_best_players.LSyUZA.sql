create function get_best_players(match_id integer) returns SETOF best_player
    language plpgsql
as
$$
declare
        tmp record;
        tmp2 record;
        best best_player;
  begin
      for tmp in (select id,date,home_team_id,away_team_id from public.match m where m.id = match_id order by date desc ) loop
        --best.match_id := tmp.id;
        best.team_id := tmp.home_team_id;
        best.team_h := true;

        for tmp2 in (with q as (select /*p.id as pid,*/p.name as pname,pa.val as paval/*,pa.date as padate*/
        from player p
                 join player_attribute pa on p.id = pa.player_id and pa.date <= tmp.date and pa.name = 'overall_rating'
        where pa.date >= all(select pat.date
                             from player pl
                            join player_attribute pat on pl.id = pat.player_id and pat.date <= tmp.date and pat.name = 'overall_rating'
                            where pl.id = p.id and pl.team_id = tmp.home_team_id)
        and p.team_id = tmp.home_team_id)
        select *
        from q
        where paval >= all(select paval from q)) loop
                best.player_name := tmp2.pname;
                best.rating := tmp2.paval;

                return next best;
        end loop;


        --best.h_name := tmp2.pname;
        --best.h_rating := tmp2.paval;

        --return next best;

/*
        with q as (select p.id as pid,p.name as pname,pa.val as paval,pa.date as padate
                   from player p
                            join player_attribute pa on p.id = pa.player_id and pa.date <= tmp.date and pa.name = 'overall_rating'
                   where pa.date >= all(select pat.date
                                        from player pl
                                                 join player_attribute pat on pl.id = pat.player_id and pat.date <= tmp.date and pat.name = 'overall_rating'
                                        where pl.id = p.id and pl.team_id = tmp.away_team_id)
                     and p.team_id = tmp.away_team_id)
        select *
        into tmp2
        from q
        where paval >= all(select paval from q)
        limit 1;

        best.player_name := tmp2.pname;
        best.rating := tmp2.paval;

        return next best;*/
        best.team_id := tmp.away_team_id;
        best.team_h := false;

        for tmp2 in (with q as (select /*p.id as pid,*/p.name as pname,pa.val as paval/*,pa.date as padate*/
                                from player p
                                         join player_attribute pa on p.id = pa.player_id and pa.date <= tmp.date and pa.name = 'overall_rating'
                                where pa.date >= all(select pat.date
                                                     from player pl
                                                              join player_attribute pat on pl.id = pat.player_id and pat.date <= tmp.date and pat.name = 'overall_rating'
                                                     where pl.id = p.id and pl.team_id = tmp.away_team_id)
                                  and p.team_id = tmp.away_team_id)
                     select *
                     from q
                     where paval >= all(select paval from q)) loop
                best.player_name := tmp2.pname;
                best.rating := tmp2.paval;

                return next best;
            end loop;
      end loop;
  end;
$$;

alter function get_best_players(integer) owner to postgres;

