create function get_best_players(match_id integer) returns SETOF best_player
    language plpgsql
as
$$
declare
        tmp record;
        tmp2 record;
        best best_player;
  begin
      for tmp in (select id,date,home_team_id,away_team_id from public.match m where m.id = match_id order by date desc ) loop
        best.team_id := tmp.home_team_id;
        best.team_h := true;

        for tmp2 in (select name,attr_val from func_get_best_players_from_team(tmp.date,tmp.home_team_id)) loop
                best.player_name := tmp2.name;
                best.rating := tmp2.attr_val;

                return next best;
        end loop;

        best.team_id := tmp.away_team_id;
        best.team_h := false;

        for tmp2 in (select name,attr_val from func_get_best_players_from_team(tmp.date,tmp.away_team_id)) loop
                best.player_name := tmp2.name;
                best.rating := tmp2.attr_val;

                return next best;
            end loop;
      end loop;
  end;
$$;

alter function get_best_players(integer) owner to postgres;

