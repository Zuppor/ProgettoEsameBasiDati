create function func_delete_country(c_id integer) returns character
    language plpgsql
as
$$
begin
    delete from country where id = c_id;

    if FOUND then
        return '0';
    else
        return '1';
    end if;

exception
    when case_not_found then
        raise info 'Id league non presente';
        return '2';
end;
$$;

alter function func_delete_country(integer) owner to postgres;

