create function func_update_league(l_id integer, new_name character varying) returns character
    language plpgsql
as
$$
begin
    update league
    set name = new_name
    where id = l_id;

    if FOUND then
        return '0';
    else
        return '1';
    end if;

exception
    when unique_violation then
        raise info 'League già presente';
        return '2';
end;
$$;

alter function func_update_league(integer, varchar) owner to postgres;

