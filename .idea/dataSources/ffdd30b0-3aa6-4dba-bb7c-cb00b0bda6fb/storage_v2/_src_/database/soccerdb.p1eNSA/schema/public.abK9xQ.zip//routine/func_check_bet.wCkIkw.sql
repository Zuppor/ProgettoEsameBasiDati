create function func_check_bet(b bets) returns integer
    language plpgsql
as
$$
begin
    --controlla che la stessa scommessa non sia messa già da un'altro impiegato della società
    --e che l'id della società non sia nullo
    perform match_id,bet,currency_id,partner_id
    from bets
    join users s on bets.partner_id = s.id
    where s.bet_society_id = (select bet_society_id from users where id = b.partner_id)
      and match_id = b.match_id and bet = b.bet and currency_id = b.currency_id;

    if FOUND then
        return 1;
    else
        if((select bet_society_id from users where id = b.partner_id) is null) then
            return 1;
        else
            return 0;
        end if;

    end if;
end;
$$;

alter function func_check_bet(bets) owner to postgres;

