create function func_player_formation_assoc(p initial_formation) returns character
    language plpgsql
as
$$
begin
        insert into initial_formation (match_id, player_id) values (p.match_id,p.player_id);

        if FOUND then
            return '0';
        else
            return '1';
        end if;

    exception
        when unique_violation then
            raise info 'Errore: condizione unique violata';
            return '2';
        when not_null_violation then
            raise info 'Errore: vincolo not null violato';
            return '3';
        when foreign_key_violation then
            raise info 'Errore: chiave esterna non presente';
            return '4';

    end;
$$;

alter function func_player_formation_assoc(initial_formation) owner to postgres;

