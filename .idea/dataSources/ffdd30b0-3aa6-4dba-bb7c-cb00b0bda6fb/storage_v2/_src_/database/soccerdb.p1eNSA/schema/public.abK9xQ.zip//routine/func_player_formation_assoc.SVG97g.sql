create function func_player_formation_assoc(p initial_formation) returns character
    language plpgsql
as
$$
begin
        if(p.player_id in (select pl.id from player pl
            join team t on pl.team_id = t.id
            join match m on t.id = m.away_team_id and m.id = p.match_id
            join match m2 on m2.home_team_id = t.id and m2.id = p.match_id)) then

            insert into initial_formation (match_id, player_id) values (p.match_id,p.player_id);

            if FOUND then
                return '0';
            else
                return '1';
            end if;
        else
            return '5';
        end if;

    exception
        when unique_violation then
            raise info 'Errore: condizione unique violata';
            return '2';
        when not_null_violation then
            raise info 'Errore: vincolo not null violato';
            return '3';
        when foreign_key_violation then
            raise info 'Errore: chiave esterna non presente';
            return '4';

    end;
$$;

alter function func_player_formation_assoc(initial_formation) owner to postgres;

