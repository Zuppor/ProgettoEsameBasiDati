create function func_get_best_players_from_team(match_date timestamp without time zone, t_id integer)
    returns TABLE(name character varying, attr_val integer)
    language plpgsql
as
$$
begin
        return query
        with q as (select p.name as pname,pa.val as paval
                   from player p
                            join player_attribute pa on p.id = pa.player_id and pa.date <= match_date and pa.name = 'overall_rating'
                   where pa.date >= all(select pat.date
                                        from player pl
                                                 join player_attribute pat on pl.id = pat.player_id and pat.date <= match_date and pat.name = 'overall_rating'
                                        where pl.id = p.id and pl.team_id = t_id)
                     and p.team_id = t_id)
        select q.pname,q.paval
        from q
        where paval >= all(select paval from q);
    end;
$$;

alter function func_get_best_players_from_team(timestamp, integer) owner to postgres;

