create function func_insert_team(t team) returns character
    language plpgsql
as
$$
begin
        insert into team values (t.id,t.short_name,t.long_name);

        if FOUND then
            return '0';
        else
            return '1';
        end if;

    exception
        when not_null_violation then
            raise info 'Errore: vincolo di not null violato';
            return '2';
        when unique_violation then
            raise info 'Errore: stai inserendo dati relativi ad un paese già presente';
            return '3';
    end;
$$;

alter function func_insert_team(team) owner to postgres;

