create function func_update_bet(m_id integer, p_id integer, b character, curr character, new_m_id integer, new_b character, new_curr character, new_val numeric) returns character
    language plpgsql
as
$$
begin
        
        update bets
        set match_id = new_m_id,bet = new_b,currency_id = new_curr, value = new_val
        where partner_id = p_id and match_id = m_id and bet = b and currency_id = curr;

        if FOUND then
            return '0';
        else
            return '1';
        end if;

        exception
            when not_null_violation then
                raise info 'Errore: vincolo di not null violato';
                return '2';
            when unique_violation then
                raise info 'Errore: stai inserendo dati relativi ad un team già presente';
                return '3';
            when foreign_key_violation then
                raise info 'Errore: vincolo chiave esterna violato';
                return '4';
    end;
$$;

alter function func_update_bet(integer, integer, char, char, integer, char, char, numeric) owner to postgres;

