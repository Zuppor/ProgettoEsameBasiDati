create materialized view classifica as
SELECT func_generate_classifica.league,
       func_generate_classifica.season,
       func_generate_classifica.l_name,
       func_generate_classifica.s_name,
       func_generate_classifica.score,
       func_generate_classifica.victories,
       func_generate_classifica.draws,
       func_generate_classifica.lost,
       func_generate_classifica.played
FROM func_generate_classifica() func_generate_classifica(league, season, l_name, s_name, score, victories, draws, lost, played)
ORDER BY func_generate_classifica.season DESC, func_generate_classifica.league, func_generate_classifica.score DESC;

alter materialized view classifica owner to postgres;

