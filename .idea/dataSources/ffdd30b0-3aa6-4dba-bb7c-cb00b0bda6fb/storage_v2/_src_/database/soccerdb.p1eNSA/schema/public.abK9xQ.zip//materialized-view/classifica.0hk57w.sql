create materialized view classifica as
SELECT match.date,
       l.name,
       match.stage,
       match.season,
       t.long_name  AS team_a,
       t2.long_name AS team_h,
       match.h_team_goal,
       match.a_team_goal
FROM (((match
    JOIN league l ON ((match.league_id = l.id)))
    JOIN team t ON ((match.away_team_id = t.id)))
         JOIN team t2 ON ((match.home_team_id = t2.id)))
ORDER BY match.season DESC, match.stage DESC;

alter materialized view classifica owner to postgres;

