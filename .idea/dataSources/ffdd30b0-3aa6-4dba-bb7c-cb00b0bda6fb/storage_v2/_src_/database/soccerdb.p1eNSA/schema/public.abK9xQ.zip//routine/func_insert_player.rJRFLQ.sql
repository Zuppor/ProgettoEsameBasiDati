create function func_insert_player(p player) returns integer
    language plpgsql
as
$$
declare
        ret_id player.id%TYPE;
    begin
        insert into player values (p.id,p.name,p.birthday,p.height,p.weight) returning id into ret_id;

        if FOUND then
            return ret_id;
        else
            return -1;
        end if;

    exception
        when not_null_violation then
            raise info 'Errore: vincolo di not null violato';
            return -2;
        when unique_violation then
            raise info 'Errore: stai inserendo dati relativi ad un giocatore già presente';
            return -3;
    end;
$$;

alter function func_insert_player(player) owner to postgres;

