create function func_insert_match(m match) returns character
    language plpgsql
as
$$
begin
    insert into match (id, home_team_id, away_team_id, season, stage, date, a_team_goal, h_team_goal, league_id, country_id, operator_id)
    values (m.id,m.home_team_id,m.away_team_id,m.season,m.stage,m.date,m.a_team_goal,m.h_team_goal,m.league_id,m.country_id,m.operator_id);

    if FOUND then
      return '0';
    else
      return '1';
    end if ;

    exception
    when not_null_violation then
      raise info 'Errore: vincolo di not null violato';
      return '2';
    when unique_violation then
      raise info 'Errore: stai inserendo dati relativi ad un match già presente';
      return '3';
    when foreign_key_violation then
      raise info 'Errore: chiave etserna non presente';
      return '4';
end;
$$;

alter function func_insert_match(match) owner to postgres;

