create function func_insert_match(m match) returns character
    language plpgsql
as
$$
begin
    insert into match (match)
    values (m);

    if FOUND then
      return '0';
    else
      return '1';
    end if ;

    exception
    when not_null_violation then
      raise info 'Errore: vincolo di not null violato';
      return '2';
    when unique_violation then
      raise info 'Errore: stai inserendo dati relativi ad un match già presente';
      return '3';
    when foreign_key_violation then
      raise info 'Errore: chiave etserna non presente';
      return '4';
end;
$$;

alter function func_insert_match(match) owner to postgres;

