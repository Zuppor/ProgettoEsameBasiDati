create function func_insert_league(league_name character varying) returns integer
    language plpgsql
as
$$
declare
    ret_id league.id%TYPE;
begin
    insert into league(name) values (league_name) returning id into ret_id;

    if FOUND then
        return ret_id;
    else
        return -1;
    end if;

exception
    when not_null_violation then
        raise info 'Errore: vincolo di not null violato';
        return -2;
    when unique_violation then
        raise info 'Errore: stai inserendo dati relativi ad una league già presente';
        select id into ret_id from league where name like league_name limit 1;
        return ret_id;
end;
$$;

alter function func_insert_league(varchar) owner to postgres;

