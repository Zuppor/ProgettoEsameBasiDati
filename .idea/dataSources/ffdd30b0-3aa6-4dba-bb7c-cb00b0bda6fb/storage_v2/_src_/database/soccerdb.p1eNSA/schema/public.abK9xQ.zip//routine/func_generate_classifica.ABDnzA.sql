create function func_generate_classifica()
    returns TABLE(score integer, victories integer, draws integer, lost integer)
    language plpgsql
as
$$
declare
        tmpSeason record;
        tmpTeam record;
    begin
        for tmpSeason in (select distinct(season) as year from public.match order by season desc) loop
            for tmpTeam in (select distinct(team.id)  as id from team join match m on team.id = m.away_team_id where m.season = tmpSeason.year) loop

                    with
                    vict as (
                        select sum(vit) as tot
                        from (
                        select count(m.id) as vit
                        from public.match m
                        where tmpTeam.id = m.home_team_id and h_team_goal > a_team_goal
                        union
                        select count(m.id)
                        from public.match m
                        where tmpTeam.id = m.away_team_id and h_team_goal < a_team_goal) as a),
                    draw as (
                        select sum(par) as tot
                        from(
                        select count(m.id) as par
                        from public.match m
                        where tmpTeam.id = m.home_team_id and h_team_goal = a_team_goal
                        union
                         select count(m.id)
                          from public.match m
                          where tmpTeam.id = m.away_team_id and h_team_goal = a_team_goal) as a),
                    lost as (
                        select sum(per) as tot
                        from (
                        select count(m.id) as per
                        from public.match m
                        where tmpTeam.id = m.home_team_id and h_team_goal < a_team_goal
                        union
                        select count(m.id)
                        from public.match m
                        where tmpTeam.id = m.away_team_id and h_team_goal > a_team_goal) as a)

                    select (((vict.tot)*3)+draw.tot) as score,vict.tot as victories,draw.tot as draws, lost.tot as lost;
                    return next;

                end loop;
            end loop;
    end;
$$;

alter function func_generate_classifica() owner to postgres;

