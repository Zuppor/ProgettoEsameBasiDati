create function func_generate_classifica() returns SETOF team_classification
    language plpgsql
as
$$
declare
        tmpSeason record;
        tmpLeague record;
        tmpTeam record;
        classification team_classification;
    begin
        for tmpSeason in (select distinct(season) as year from public.match order by season desc) loop
            for tmpLeague in (select id,name from league) loop
                for tmpTeam in (select distinct(t.id) as id,t.long_name,t.short_name from team t join match m on (t.id = m.away_team_id or t.id = m.home_team_id) where m.season = tmpSeason.year and m.league_id = tmpLeague.id) loop

                    classification.season := tmpSeason.year;
                    classification.league := tmpLeague.name;
                    classification.l_name := tmpTeam.long_name;
                    classification.s_name := tmpTeam.short_name;

                    classification.victories := (select tot
                    from (
                             select sum(vit) as tot
                             from (
                                      select count(m.id) as vit
                                      from public.match m
                                      where tmpTeam.id = m.home_team_id and h_team_goal > a_team_goal
                                      union
                                      select count(m.id)
                                      from public.match m
                                      where tmpTeam.id = m.away_team_id and h_team_goal < a_team_goal) as a
                             ) as b);

                    classification.draws := (select tot
                    from (
                             select sum(par) as tot
                             from(
                                     select count(m.id) as par
                                     from public.match m
                                     where tmpTeam.id = m.home_team_id and h_team_goal = a_team_goal
                                     union
                                     select count(m.id)
                                     from public.match m
                                     where tmpTeam.id = m.away_team_id and h_team_goal = a_team_goal) as a
                             ) as b);

                    classification.lost := (select tot
                    from(
                            select sum(per) as tot
                            from (
                                     select count(m.id) as per
                                     from public.match m
                                     where tmpTeam.id = m.home_team_id and h_team_goal < a_team_goal
                                     union
                                     select count(m.id)
                                     from public.match m
                                     where tmpTeam.id = m.away_team_id and h_team_goal > a_team_goal) as a
                            ) as b);

                    classification.score := ((classification.victories*3)+classification.draws);
                    classification.played := classification.victories+classification.draws+classification.lost;

                    return next classification;

                end loop;
            end loop;
        end loop;
    end;
$$;

alter function func_generate_classifica() owner to postgres;

