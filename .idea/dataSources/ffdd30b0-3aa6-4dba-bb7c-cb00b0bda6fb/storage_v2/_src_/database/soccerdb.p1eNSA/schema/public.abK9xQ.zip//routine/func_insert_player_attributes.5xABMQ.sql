create function func_insert_player_attributes(attr player_attribute) returns character
    language plpgsql
as
$$
begin
        insert into player_attribute (player_attribute) values (attr);

        if FOUND then
            return '0';
        else
            return '1';
        end if;

    exception
        when check_violation then
            raise info 'Errore: condizione check violata';
            return '2';
        when not_null_violation then
            raise info 'Errore: vincolo not null violato';
            return '3';
        when foreign_key_violation then
            raise info 'Errore: chiave etserna non presente';
            return '4';

    end;
$$;

alter function func_insert_player_attributes(player_attribute) owner to postgres;

