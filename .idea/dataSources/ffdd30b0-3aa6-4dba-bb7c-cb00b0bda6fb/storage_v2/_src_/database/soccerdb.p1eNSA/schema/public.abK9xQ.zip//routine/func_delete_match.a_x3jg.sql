create function func_delete_match(m_id integer, op_id integer) returns character
    language plpgsql
as
$$
begin

        delete from public.match where id = m_id and operator_id = op_id;


        if FOUND then
            return '0';
        else
            return '1';
        end if;
    end;
$$;

alter function func_delete_match(integer, integer) owner to postgres;

