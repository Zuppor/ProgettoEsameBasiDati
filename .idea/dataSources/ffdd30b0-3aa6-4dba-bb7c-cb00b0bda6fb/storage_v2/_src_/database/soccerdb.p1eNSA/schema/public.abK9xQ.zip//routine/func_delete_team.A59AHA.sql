create function func_delete_team(t_id integer) returns character
    language plpgsql
as
$$
begin
    delete from team where id = t_id;

    if FOUND then
        return '0';
    else
        return '1';
    end if;

exception
    when case_not_found then
        raise info 'Errore: team non presente';
        return '2';

end;
$$;

alter function func_delete_team(integer) owner to postgres;

