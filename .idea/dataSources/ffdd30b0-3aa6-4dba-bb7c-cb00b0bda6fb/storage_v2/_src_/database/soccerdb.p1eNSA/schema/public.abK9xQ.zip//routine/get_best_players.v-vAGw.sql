create function get_best_players() returns SETOF best_players
    language plpgsql
as
$$
declare
        tmp record;
        tmp2 record;
        best best_players;
  begin
      for tmp in (select id,date,home_team_id,away_team_id from public.match order by date desc ) loop
        best.match_id := tmp.id;
        best.h_team := tmp.home_team_id;
        best.a_team := tmp.away_team_id;

        select p.name,pa.val
        into tmp2
        from player p
        join player_attribute pa on p.id = pa.player_id and pa.date <= tmp.date and pa.name = 'overall_rating'
        join team t on p.team_id = t.id and p.team_id = tmp.home_team_id
        where val >= all(select pa.val
                                  from player p
                                   join player_attribute pa on p.id = pa.player_id and pa.date <= tmp.date and pa.name = 'overall_rating'
                                   join team t on p.team_id = t.id and p.team_id = tmp.home_team_id)
        and pa.date >= all (select date from player_attribute where p.id = pa.player_id and name = 'overall_rating' and date <= tmp.date);
        --order by pa.date desc limit 1;

        best.h_name := tmp2.name;
        best.h_rating := tmp2.val;

/*
        select p.name,pa.val
        into tmp2
        from player p
                 join player_attribute pa on p.id = pa.player_id and pa.date <= tmp.date and pa.name like 'overall_rating'
                 join team t on p.team_id = t.id and p.team_id = tmp.away_team_id
        where val >= all(select pa.val
                                    from player p
                                     join player_attribute pa on p.id = pa.player_id and pa.date <= tmp.date and pa.name like 'overall_rating'
                                     join team t on p.team_id = t.id and p.team_id = tmp.away_team_id);*/

        select p.name,pa.val
        into tmp2
        from player p
                 join player_attribute pa on p.id = pa.player_id and pa.date <= tmp.date and pa.name = 'overall_rating'
                 join team t on p.team_id = t.id and p.team_id = tmp.away_team_id
        where val >= all(select pa.val
                         from player p
                                  join player_attribute pa on p.id = pa.player_id and pa.date <= tmp.date and pa.name = 'overall_rating'
                                  join team t on p.team_id = t.id and p.team_id = tmp.away_team_id)
        order by pa.date desc limit 1;

        best.a_name := tmp2.name;
        best.a_rating := tmp2.val;

        return next best;
      end loop;
  end;
$$;

alter function get_best_players() owner to postgres;

