create function get_best_players() returns SETOF best_players
    language plpgsql
as
$$
declare
      tmp record;
      tmp2 best_players;
  begin
      for tmp in (select id,date,home_team_id,away_team_id from match order by date desc ) loop
        tmp2.match_id := tmp.id;

        select name,birthday,height,weight,overall_rating
        into tmp2.h_name,tmp2.h_birthday,tmp2.h_height,tmp2.h_weight,tmp2.h_rating
        from player
        join player_attribute pa on player.id = pa.player_id and pa.date <= tmp.date
        join participation p on player.id = p.player_id and p.team_id = tmp.home_team_id
        having overall_rating >= all(select overall_rating
                                  from player
                                   join player_attribute pa on player.id = pa.player_id and pa.date <= tmp.date
                                   join participation p on player.id = p.player_id and p.team_id = tmp.home_team_id);

        select name,birthday,height,weight,overall_rating
        into tmp2.a_name,tmp2.a_birthday,tmp2.a_height,tmp2.a_weight,tmp2.a_rating
        from player
         join player_attribute pa on player.id = pa.player_id and pa.date <= tmp.date
         join participation p on player.id = p.player_id and p.team_id = tmp.away_team_id
        having overall_rating >= all(select overall_rating
                                  from player
                                   join player_attribute pa on player.id = pa.player_id and pa.date <= tmp.date
                                   join participation p on player.id = p.player_id and p.team_id = tmp.away_team_id);

        return next tmp2;
      end loop;
  end;
$$;

alter function get_best_players() owner to postgres;

