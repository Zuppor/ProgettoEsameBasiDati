create function get_best_players() returns SETOF best_players
    language plpgsql
as
$$
declare
        tmp record;
        tmp2 record;
        best best_players;
  begin
      for tmp in (select id,date,home_team_id,away_team_id from public.match order by date desc ) loop
        best.match_id := tmp.id;
        best.h_team := tmp.home_team_id;
        best.a_team := tmp.away_team_id;

        select p.name,pa.overall_rating
        into tmp2
        from player p
        join player_attribute pa on p.id = pa.player_id and pa.date <= tmp.date
        join team t on p.team_id = t.id and p.team_id = tmp.home_team_id
        where overall_rating >= all(select overall_rating
                                  from player p
                                   join player_attribute pa on p.id = pa.player_id and pa.date <= tmp.date
                                   join team t on p.team_id = t.id and p.team_id = tmp.home_team_id);

        best.h_name := tmp2.name;
        best.h_rating := tmp2.overall_rating;


        select p.name,pa.overall_rating
        into tmp2
        from player p
                 join player_attribute pa on p.id = pa.player_id and pa.date <= tmp.date
                 join team t on p.team_id = t.id and p.team_id = tmp.away_team_id
        where overall_rating >= all(select overall_rating
                                    from player p
                                     join player_attribute pa on p.id = pa.player_id and pa.date <= tmp.date
                                     join team t on p.team_id = t.id and p.team_id = tmp.away_team_id);

        best.a_name := tmp2.name;
        best.a_rating := tmp2.overall_rating;

        return next best;
      end loop;
  end;
$$;

alter function get_best_players() owner to postgres;

