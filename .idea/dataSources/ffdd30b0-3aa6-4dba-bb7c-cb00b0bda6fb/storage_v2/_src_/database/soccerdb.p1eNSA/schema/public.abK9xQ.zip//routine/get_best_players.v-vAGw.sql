create function get_best_players() returns SETOF best_players
  language plpgsql
as
$$
declare
      tmp record;
      tmp2 best_players;
  begin
      for tmp in (select id,date,home_team_id,away_team_id from match order by date desc ) loop
        tmp2.match_id := tmp.id;

        select name,birthday,height,weight
        into tmp2.h_name,tmp2.h_birthday,tmp2.h_height,tmp2.h_weight
        from player
        join player_attribute on player.id = player_attribute.player_id
        join participation p on player.id = p.player_id
        where player_attribute.date <= tmp.date and p.team_id = tmp.home_team_id
        order by player_attribute.date desc
        limit 1;

        select name,birthday,height,weight
        into tmp2.a_name,tmp2.a_birthday,tmp2.a_height,tmp2.a_weight
        from player
        join player_attribute on player.id = player_attribute.player_id
        join participation p on player.id = p.player_id
        where player_attribute.date <= tmp.date and p.team_id = tmp.away_team_id
        order by player_attribute.date desc
        limit 1;

        return next tmp2;
      end loop;
  end;
$$;

alter function get_best_players() owner to postgres;

