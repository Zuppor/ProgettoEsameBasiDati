create function func_insert_team(team_id integer, short character, long character varying) returns character
    language plpgsql
as
$$
begin
        insert into team(id,short_name,long_name) values (team_id,short,long);

        if FOUND then
            return '0';
        else
            return '1';
        end if;

    exception
        when not_null_violation then
            raise info 'Errore: vincolo di not null violato';
            return '2';
        when unique_violation then
            raise info 'Errore: stai inserendo dati relativi ad un team già presente';
            return '3';
    end;
$$;

alter function func_insert_team(integer, char, varchar) owner to postgres;

